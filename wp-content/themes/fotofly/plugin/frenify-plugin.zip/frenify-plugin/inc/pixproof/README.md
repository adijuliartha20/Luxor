[![Build Status](https://travis-ci.org/pixelgrade/pixproof.svg?branch=wporg)](https://travis-ci.org/pixelgrade/pixproof)

PixProof
========

WordPress photo gallery proofing plugin. Using special protected galleries you will allow your clients to examine and approve your photos.

Always use the [stable version](https://wordpress.org/plugins/pixproof) from wordpress.org
