<?php
/**
 * Class for Pre-Built templates
 *
 * @package   frenifyCore
 * @author	frenify
 * @link	  http://theme-frenify.com
 * @copyright frenify
 */

if( ! class_exists( 'fotofly_fn_Core_Prebuilt_Templates' ) ) {

	class fotofly_fn_Core_Prebuilt_Templates {

		/**
		 * Instance of this class.
		 *
		 * @since	2.0.0
		 *
		 * @var	  object
		 */
		protected static $instance = null;
		/**
		 * content of templates.
		 *
		 * @since	2.0.0
		 *
		 * @var	  string
		 */
		 protected static $content = 'YToyOntzOjY6IllvbmRpbSI7czo1NjQzOiJbZnVsbHdpZHRoIGJveGVkPSJ5ZXMiIGJhY2tncm91bmRfY29sb3I9IiMwMDAwMDAiIGJhY2tncm91bmRfY29sb3JfcmF0ZT0iMC41IiBiYWNrZ3JvdW5kX2ltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9wYXIxLmpwZyIgYmFja2dyb3VuZF9yZXBlYXQ9Im5vLXJlcGVhdCIgYmFja2dyb3VuZF9wb3NpdGlvbj0ibGVmdCB0b3AiIGJhY2tncm91bmRfdHlwZT0icGFyYWxsYXgiIHBhcmFsbGF4X3NwZWVkPSIwLjUiIGJnc2xpZGVfZGlyZWN0aW9uPSJob3IiIGJnc2xpZGVfeGF4aXM9IjAiIGJnc2xpZGVfeWF4aXM9IjAiIGJnc2xpZGVfcmF0ZT0iMzAiIG1hcmdpbl90b3A9IjAiIG1hcmdpbl9ib3R0b209IjAiIHBhZGRpbmdfdG9wPSIwcHgiIHBhZGRpbmdfYm90dG9tPSIwcHgiIG1lbnVfYW5jaG9yPSJzZGZzIiBjbGFzcz0iIiBpZD0iIl1baW50cm8gbWFpbl90ZXh0PSJXZWxjb21lIHRvIEJlYXV0eSIgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L3NsaWRlcl9sb2dvLnBuZyIgYnV0dG9uX3RleHQ9IkV4cGxvcmUiIGJ1dHRvbl9ocmVmPSIjIiBidXR0b25faG92ZXI9Im9uIiB0b2Rvd249ImhlbGxvbWUiIGNsYXNzPSIiIGlkPSIiXSBbL2ludHJvXVsvZnVsbHdpZHRoXVtmdWxsd2lkdGggYm94ZWQ9InllcyIgYmFja2dyb3VuZF9jb2xvcj0iIiBiYWNrZ3JvdW5kX2NvbG9yX3JhdGU9IjAuNCIgYmFja2dyb3VuZF9pbWFnZT0iIiBiYWNrZ3JvdW5kX3JlcGVhdD0icmVwZWF0IiBiYWNrZ3JvdW5kX3Bvc2l0aW9uPSJsZWZ0IHRvcCIgYmFja2dyb3VuZF90eXBlPSJwYXJhbGxheCIgcGFyYWxsYXhfc3BlZWQ9IjAuNSIgYmdzbGlkZV9kaXJlY3Rpb249ImhvciIgYmdzbGlkZV94YXhpcz0iMCIgYmdzbGlkZV95YXhpcz0iMCIgYmdzbGlkZV9yYXRlPSIzMCIgbWFyZ2luX3RvcD0iMCIgbWFyZ2luX2JvdHRvbT0iMCIgcGFkZGluZ190b3A9IjE1MHB4IiBwYWRkaW5nX2JvdHRvbT0iMTUwcHgiIG1lbnVfYW5jaG9yPSJnZXR0byIgY2xhc3M9IiIgaWQ9ImhlbGxvbWUiXVt0aXRsZSBtYXJnaW5fdG9wPSIxMDAiIG1hcmdpbl9ib3R0b209IiIgc2VjX2NvbnRlbnQ9IlNlcnZpY2VzIiBjbGFzcz0iIiBpZD0iIl1PdXIgQW1hemluZ1svdGl0bGVdW3Rlc3RpbW9uaWFscyBtYXJnaW5fdG9wPSIwIiBtYXJnaW5fYm90dG9tPSIxMDAiIGNsYXNzPSIiIGlkPSIiXVt0ZXN0aW1vbmlhbCBuYW1lPSJUZXN0Il1mZ2RmZ2RmZ1svdGVzdGltb25pYWxdW3Rlc3RpbW9uaWFsIG5hbWU9ImRmZ2RmZ2RmZ2YiXSBkZmdkZmdkIGZnZGYgZ2RmZ2RbL3Rlc3RpbW9uaWFsXVsvdGVzdGltb25pYWxzXVtzZXJ2aWNldGFicyBtYXJnaW5fdG9wPSI1MCIgbWFyZ2luX2JvdHRvbT0iMTEwIiBjbGFzcz0iIiBpZD0iIl1bc2VydmljZXRhYiB0aXRsZT0iTW9kZXJuIFN0eWxpbmciIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9wYXI0LTE1MHgxNTAuanBnIiBsaW5rPSIjIl1JIHRoaW5rIHBlb3BsZSBhcmUgYXdlc29tZSB3aGVuIHRoZXkgaGF2ZSBzb21lIHNlbnNlIG9mIHN0eWxlLCB3aGVuIHRoZXkgZXhwcmVzcyB0aGVpciBvd24gb3BpbmlvbnMsIHdoZW4gdGhleSBhcmUgY3JlYXRpdmUsIHdoZW4gdGhleSBoYXZlIGNoYXJhY3Rlci5bL3NlcnZpY2V0YWJdW3NlcnZpY2V0YWIgdGl0bGU9Ik1ha2V1cCAmIE1ha2VvdmVyIiBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvc2VySW50cm8yLTE1MHgxNTAuanBnIiBsaW5rPSIjIl1DbG90aGluZyBhbmQgbWFrZXVwIGFuZCBoYWlyIGFuZCBhbGwgb2YgdGhhdCBzbyBtdWNoIGluZGljYXRlcyB0aGUga2luZCBvZiBwZXJzb24geW91IGFyZSBpbnNpZGUgYW5kIHRoZSBwZXJzb24geW91IGFyZSBwcmVzZW50aW5nIG9uIHRoZSBvdXRzaWRlLlsvc2VydmljZXRhYl1bc2VydmljZXRhYiB0aXRsZT0iSGFpciBTdHlsaW5nIiBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvc2VySW50cm8zLTE1MHgxNTAuanBnIiBsaW5rPSIjIl1UaGVyZSdzIGEgcmVhc29uIHdoeSBmb3J0eSwgZmlmdHksIGFuZCBzaXh0eSBkb24ndCBsb29rIHRoZSB3YXkgdGhleSB1c2VkIHRvLCBhbmQgaXQncyBub3QgYmVjYXVzZSBvZiBmZW1pbmlzbSwgb3IgYmV0dGVyIGxpdmluZyB0aHJvdWdoIGV4ZXJjaXNlLiBJdCdzIGJlY2F1c2Ugb2YgaGFpciBkeWUuWy9zZXJ2aWNldGFiXVsvc2VydmljZXRhYnNdW2dhbGxlcnkgc2xpZGVfYXV0b3BsYXk9Im9uIiBzbGlkZV9zcGVlZD0iNDAwMCIgbWFyZ2luX3RvcD0iNTAiIG1hcmdpbl9ib3R0b209IjExMCIgY2xhc3M9IiIgaWQ9IiJdW2dpbWcgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L3BhcjEtMTUweDE1MC5qcGciXVsvZ2ltZ11bZ2ltZyBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvc2VySW50cm8xLTE1MHgxNTAuanBnIl1bL2dpbWddW2dpbWcgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L3NlckludHJvMy0xNTB4MTUwLmpwZyJdWy9naW1nXVtnaW1nIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9zZXJJbnRybzItMTUweDE1MC5qcGciXVsvZ2ltZ11bZ2ltZyBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvcGFyNC0xNTB4MTUwLmpwZyJdWy9naW1nXVtnaW1nIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9wYXIxLTE1MHgxNTAuanBnIl1bL2dpbWddW2dpbWcgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L3NlckludHJvMS0xNTB4MTUwLmpwZyJdWy9naW1nXVtnaW1nIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9zZXJJbnRybzMtMTUweDE1MC5qcGciXVsvZ2ltZ11bZ2ltZyBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvc2VySW50cm8yLTE1MHgxNTAuanBnIl1bL2dpbWddW2dpbWcgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L3BhcjQtMTUweDE1MC5qcGciXVsvZ2ltZ11bL2dhbGxlcnldW2NsaWVudHMgY2xpZW50X3R5cGU9ImIiIGNsaWVudF9jb2w9IjYiIGNsaWVudF9jb2xvcj0iI2RkMzMzMyIgY2xpZW50X29wYWNpdHk9IjAuNyIgbWFyZ2luX3RvcD0iNTAiIG1hcmdpbl9ib3R0b209IjExMCIgY2xhc3M9IiIgaWQ9IiJdW2NsaWVudCBsaW5rPSIjIiBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvYjEucG5nIl1bY2xpZW50IGxpbms9IiMiIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9iMi5wbmciXVtjbGllbnQgbGluaz0iIyIgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L2IzLnBuZyJdW2NsaWVudCBsaW5rPSIjIiBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvYjQucG5nIl1bY2xpZW50IGxpbms9IiMiIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9iNS5wbmciXVtjbGllbnQgbGluaz0iIyIgaW1hZ2U9Imh0dHA6Ly9sb2NhbGhvc3QvZGVtb3MvYXZpcXVlL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE1LzA4L2I3LnBuZyJdW2NsaWVudCBsaW5rPSIjIiBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvYjgucG5nIl1bL2NsaWVudHNdWy9mdWxsd2lkdGhdW2Z1bGx3aWR0aCBib3hlZD0ieWVzIiBiYWNrZ3JvdW5kX2NvbG9yPSIiIGJhY2tncm91bmRfY29sb3JfcmF0ZT0iMC40IiBiYWNrZ3JvdW5kX2ltYWdlPSIiIGJhY2tncm91bmRfcmVwZWF0PSJyZXBlYXQiIGJhY2tncm91bmRfcG9zaXRpb249ImxlZnQgdG9wIiBiYWNrZ3JvdW5kX3R5cGU9InBhcmFsbGF4IiBwYXJhbGxheF9zcGVlZD0iMC41IiBiZ3NsaWRlX2RpcmVjdGlvbj0iaG9yIiBiZ3NsaWRlX3hheGlzPSIwIiBiZ3NsaWRlX3lheGlzPSIwIiBiZ3NsaWRlX3JhdGU9IjMwIiBtYXJnaW5fdG9wPSIwIiBtYXJnaW5fYm90dG9tPSIwIiBwYWRkaW5nX3RvcD0iMTUwcHgiIHBhZGRpbmdfYm90dG9tPSIxNTBweCIgbWVudV9hbmNob3I9ImZ1cnJhIiBjbGFzcz0iIiBpZD0iIl1bdGhlbWVkb190YWJzIHNraW49ImxpZ2h0IiBwb3NpdGlvbj0ibGVmdCIgbWFyZ2luX3RvcD0iNTAiIG1hcmdpbl9ib3R0b209IjkwIiBjbGFzcz0iIiBpZD0iIl1bdGhlbWVkb190YWIgdGl0bGU9IlRhYiAxIl1UYWIgY29udGVudFsvdGhlbWVkb190YWJdW3RoZW1lZG9fdGFiIHRpdGxlPSJUYWIgMiJdVGFiIGNvbnRlbnQgMlsvdGhlbWVkb190YWJdWy90aGVtZWRvX3RhYnNdW2FjY29yZGlvbiBza2luPSJkYXJrIiBtYXJnaW5fdG9wPSI5MCIgbWFyZ2luX2JvdHRvbT0iOTAiIGNsYXNzPSIiIGlkPSIiXVthY2MgdGl0bGU9IkFjY29yZGlvbiBUaXRsZSAxIiBvcGVuPSJubyJdVGVzdCBDb250ZW50Wy9hY2NdW2FjYyB0aXRsZT0iVGhpcyBpcyBteSBmYXVsdCIgb3Blbj0ieWVzIl1oYSBoYSBoYVsvYWNjXVsvYWNjb3JkaW9uXVtwcm9ncmVzcyB2YWx1ZT0iOTEiIGZpbGxlZGNvbG9yPSIjMWU3M2JlIiBzdHJpcGVkPSJvZmYiIHNpemU9Im1lZGl1bSIgcm91bmRlZD0iYyIgbWFyZ2luX3RvcD0iMjAiIG1hcmdpbl9ib3R0b209IjkwIiBjbGFzcz0iIiBpZD0iIl1QaG90b3Nob3AgTWVbL3Byb2dyZXNzXVtwcm9ncmVzcyB2YWx1ZT0iNzAiIGZpbGxlZGNvbG9yPSIjZGQ5OTMzIiBzdHJpcGVkPSJvbiIgc2l6ZT0iYmlnIiByb3VuZGVkPSJvZmYiIG1hcmdpbl90b3A9IjIwIiBtYXJnaW5fYm90dG9tPSIyMCIgY2xhc3M9IiIgaWQ9IiJdUGhvdG9zaG9wWy9wcm9ncmVzc11bcHJvZ3Jlc3MgdmFsdWU9IjU4IiBmaWxsZWRjb2xvcj0iI2RkMzMzMyIgc3RyaXBlZD0ib24iIHNpemU9InNtYWxsIiByb3VuZGVkPSJhIiBtYXJnaW5fdG9wPSIyMCIgbWFyZ2luX2JvdHRvbT0iMjAiIGNsYXNzPSIiIGlkPSIiXUFkb2JlIElsbHVzdHJhdG9yWy9wcm9ncmVzc11bL2Z1bGx3aWR0aF1bcHJvZ3Jlc3MgdmFsdWU9IjU4IiBmaWxsZWRjb2xvcj0iI2RkMzMzMyIgc3RyaXBlZD0ib24iIHNpemU9InNtYWxsIiByb3VuZGVkPSJhIiBtYXJnaW5fdG9wPSIyMCIgbWFyZ2luX2JvdHRvbT0iMjAiIGNsYXNzPSIiIGlkPSIiXUFkb2JlIElsbHVzdHJhdG9yWy9wcm9ncmVzc10iO3M6NDoiVGVzdCI7czoxNTUzOiJbc2VydmljZSBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDkvaG90c3BvdDEuanBnIiB0aXRsZT0iU2lsa3kgTGF3YSBTdHlsZSIgZHVyYXRpb249IjM1IC00NSBtaW4iIHByaWNlPSIkMzQuMDAiIG1hcmdpbl90b3A9IjAiIG1hcmdpbl9ib3R0b209IjQwcHgiIGNsYXNzPSIiIGlkPSIiXVRoZSBzZWNyZXQgdG8gdGhlIG1vdGlvbiBhbmQgdGhlIGJyZWF0aHRha2luZyB2b2x1bWUgb2YgdGhpcyBsb25nIGhhaXIgbG9vayBpcyBwdXJlbHkgaW4gdGhlIHN0eWxpbmcuWy9zZXJ2aWNlXVtzZXJ2aWNlIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOS9ob3RzcG90MS5qcGciIHRpdGxlPSJTaWxreSBMYXdhIFN0eWxlIiBkdXJhdGlvbj0iMzUgLTQ1IG1pbiIgcHJpY2U9IiQzNy4wMCIgbWFyZ2luX3RvcD0iMCIgbWFyZ2luX2JvdHRvbT0iNDBweCIgY2xhc3M9IiIgaWQ9IiJdVGhlIHNlY3JldCB0byB0aGUgbW90aW9uIGFuZCB0aGUgYnJlYXRodGFraW5nIHZvbHVtZSBvZiB0aGlzIGxvbmcgaGFpciBsb29rIGlzIHB1cmVseSBpbiB0aGUgc3R5bGluZy5bL3NlcnZpY2VdW29uZV9oYWxmIGxhc3Q9Im5vIiBtYXJnaW5fdG9wPSIwcHgiIG1hcmdpbl9ib3R0b209IjBweCIgY2xhc3M9IiIgaWQ9IiJdW3NlcnZpY2VwYWNrIGltYWdlPSJodHRwOi8vbG9jYWxob3N0L2RlbW9zL2F2aXF1ZS93cC1jb250ZW50L3VwbG9hZHMvMjAxNS8wOC9wYXI0LmpwZyIgdGl0bGU9IkJlYXV0eSBTa2luIFBhY2thZ2UiIGR1cmF0aW9uPSIyLTMgaG91cnMiIHRvdGFsY29zdD0iJDk5LjAwIiBib29raW5nPSJvbiIgbWFyZ2luX3RvcD0iMCIgbWFyZ2luX2JvdHRvbT0iMCIgY2xhc3M9IiIgaWQ9IiJdW3NwIHRpdGxlPSJCb2R5IFNjcnViICIgcHJpY2U9IiQyNy4wMCJdWy9zcF1bc3AgdGl0bGU9IkhvdCBPaWwgQm9keSBUcmVhdG1lbnQiIHByaWNlPSIkMjcuMDAiXVsvc3BdW3NwIHRpdGxlPSJUcmFkaXRpb25hbCBNYXNzYWdlICIgcHJpY2U9IiQyNy4wMCJdWy9zcF1bL3NlcnZpY2VwYWNrXVsvb25lX2hhbGZdW29uZV9oYWxmIGxhc3Q9InllcyIgbWFyZ2luX3RvcD0iMHB4IiBtYXJnaW5fYm90dG9tPSIwcHgiIGNsYXNzPSIiIGlkPSIiXVtzZXJ2aWNlcGFjayBpbWFnZT0iaHR0cDovL2xvY2FsaG9zdC9kZW1vcy9hdmlxdWUvd3AtY29udGVudC91cGxvYWRzLzIwMTUvMDgvcGFyNC5qcGciIHRpdGxlPSJCZWF1dHkgU2tpbiBQYWNrYWdlIiBkdXJhdGlvbj0iMi0zIGhvdXJzIiB0b3RhbGNvc3Q9IiQ5OS4wMCIgYm9va2luZz0ib24iIG1hcmdpbl90b3A9IjAiIG1hcmdpbl9ib3R0b209IjAiIGNsYXNzPSIiIGlkPSIiXVtzcCB0aXRsZT0iQm9keSBTY3J1YiAiIHByaWNlPSIkMjcuMDAiXVsvc3BdW3NwIHRpdGxlPSJIb3QgT2lsIEJvZHkgVHJlYXRtZW50IiBwcmljZT0iJDI3LjAwIl1bL3NwXVtzcCB0aXRsZT0iVHJhZGl0aW9uYWwgTWFzc2FnZSAiIHByaWNlPSIkMjcuMDAiXVsvc3BdWy9zZXJ2aWNlcGFja11bL29uZV9oYWxmXSI7fQ==';

		
		function __construct() {
			//construct
		}

		/**
		 * Return an instance of this class.
		 *
		 * @since	 2.0.0
		 *
		 * @return	object	A single instance of this class.
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;

		}
		/**
		 * Function to get signle page content
		 *
		 * @since	 2.0.0
		 *
		 * @return	String	Page content
		 */
		public function get_single_template() {
			
			$content 	= unserialize( base64_decode( self::$content ) );
			$page 		= stripslashes( $content[ $_POST['ID'] ] );
			
			return $page;
		}
		/**
		 * Function to get tab content for pre-built templates
		 *
		 * @since	 2.0.0
		 *
		 * @return	String	String having tab content
		 */
		public function get_prebuilt_templates () {
			
			$columns		= 6; //number of columns
			$content 		= '<div id="pre_built_templates_wrapper"><div id="custom_templates_right" class="custom_pre_built">';
			//get templates data
			$templates 		= unserialize( base64_decode( self::$content ) );
			
			//if value exists and there are more than 1 number of templates
			if ( $templates != false && count( $templates ) > 0 ) {
				//generate column combinations
				$combinations 	= frenifyHelper::generate_column_combinations( count( $templates ), $columns );
				//add data in each column
				for( $i = 0; $i < $columns; $i++) {
					//if no data available for this column then break
					if( $combinations[$i] == 0 ) { break; }
					$counter = 0 ;
					$content.= ' <div class="pre_built_templates_section">';
					
					foreach( $templates as $key => $value ) {
						
						$content.= ' <div class="template_selection_wrapper"> ';
						$content.= ' <a class="fotofly_fn_pre_built_template templates_selection" data-id="'.$key.'" ';
						$content.= ' href="JavaScript:void(0)">'.$key.'</a>';
						$content.= ' </div>';
						
						//remove current element from array for next iteration
						unset( $templates[$key] );
						$counter++;
						//if reached combination value then break loop
						if ( $counter == $combinations[$i] ) { break; }
					}
					$content.= '</div>';
				}
			}
			
			$content.=	'</div></div>';
			
			return $content;

		}

	}
	
}