<?php 
// Silence is golden
// Golden is deprecated